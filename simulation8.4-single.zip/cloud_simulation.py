# cloud_simulation.py
"""
Cloud Simulation for Solar Farm Simulation
Handles cloud generation, movement, and rendering
"""
import math
import random
import numpy as np
from typing import List, Dict, Tuple, Optional
from collections import deque, namedtuple
import pygame
import functools
import sim_config as CFG
def clamp(val, lo, hi): return lo if val < lo else hi if val > hi else val
# Define CloudPuff class for EnhancedCloudParcel
class CloudPuff:
    __slots__ = ("rel_x", "rel_y", "width", "height", "opacity", "original_width",
                "original_height", "rotation")
    def __init__(self, rel_x, rel_y, width, height):
        self.rel_x, self.rel_y = float(rel_x), float(rel_y)
        self.width = self.original_width = width
        self.height = self.original_height = height
        self.rotation = random.random() * 2 * math.pi
        self.opacity = 0.0
    def fade_toward(self, target):
        """Gradually change opacity toward target value."""
        self.opacity += (target - self.opacity) * CFG.OPACITY_RAMP
        self.opacity = clamp(self.opacity, 0, CFG.MAX_OPACITY)
class EnhancedCloudParcel:
    def __init__(self, frame_idx, wind_field, cloud_type='cumulus', altitude=None):
        self.birth = frame_idx
        self.cloud_type = cloud_type
        self.last_update_time = 0
        self.simulation_time = 0.0
        # Set parcel altitude
        if altitude is None:
            if not CFG.SINGLE_CLOUD_MODE:
                # Random altitude with distribution favoring low-mid levels
                if random.random() < 0.7:
                    # 70% low-mid clouds
                    self.altitude = random.uniform(0.5, 2.0)
                else:
                    # 30% higher clouds
                    self.altitude = random.uniform(2.0, 4.0)
            else:
                # For single cloud mode, use mid altitude
                self.altitude = 1.5
        else:
            self.altitude = altitude
        # Initial position
        if CFG.SINGLE_CLOUD_MODE:
            self.precise_x = CFG.DOMAIN_SIZE_M * 0.25
            self.precise_y = CFG.DOMAIN_SIZE_M * 0.25
        else:
            # Get wind vector to determine spawn edge
            wind_speed, wind_direction = wind_field.sample(CFG.DOMAIN_SIZE_M/2, CFG.DOMAIN_SIZE_M/2, self.altitude)
            
            # Fall back to inside-box spawn when wind < 0.5 m/s
            if wind_speed < 0.5:
                buffer = CFG.DOMAIN_SIZE_M * 0.15
                self.precise_x = random.uniform(buffer, CFG.DOMAIN_SIZE_M - buffer)
                self.precise_y = random.uniform(buffer, CFG.DOMAIN_SIZE_M - buffer)
            else:
                # Use edge spawn based on wind direction
                self.precise_x, self.precise_y = self._initial_position(wind_field)
        self.x, self.y = int(self.precise_x), int(self.precise_y)
        self.position_history_x = deque([self.precise_x] * CFG.POSITION_HISTORY_LENGTH, maxlen=CFG.POSITION_HISTORY_LENGTH)
        self.position_history_y = deque([self.precise_y] * CFG.POSITION_HISTORY_LENGTH, maxlen=CFG.POSITION_HISTORY_LENGTH)
        # Get initial wind vector
        self.vx, self.vy = self._wind_to_velocity(wind_field)
        self.ws = math.sqrt(self.vx**2 + self.vy**2)
        self.wd = math.degrees(math.atan2(self.vy, self.vx)) % 360
        self.velocity_history_x = deque([self.vx] * 4, maxlen=4)
        self.velocity_history_y = deque([self.vy] * 4, maxlen=4)
        self.acceleration_x = 0.0
        self.acceleration_y = 0.0
        self.last_physics_step = 0.0
        self.render_x = self.precise_x
        self.render_y = self.precise_y
        # Make cloud puffs with altitudes based on parcel altitude
        self.puffs = self._make_puffs()
        self.effective_radius = max(max(p.width, p.height)/2 for p in self.puffs) + 400
        # Movement smoothing variables
        self.prev_dx = 0.0
        self.prev_dy = 0.0
        # Pygame rendering additions
        self.scale_factor = 1.0 / CFG.DOMAIN_SIZE_M  # For converting to screen coordinates
    def _wind_to_velocity(self, wind_field):
        """Convert wind to velocity in domain units per frame."""
        # Sample wind at cloud position and altitude
        wind_speed, wind_direction = wind_field.sample(self.precise_x, self.precise_y, self.altitude)
        
        # Convert direction to radians
        direction_rad = math.radians(wind_direction)
        
        # Convert m/s to domain units per frame
        scale = CFG.PHYSICS_TIMESTEP * CFG.DOMAIN_SIZE_M / 1000.0
        
        # Calculate velocity components
        vx = wind_speed * math.cos(direction_rad) * scale
        vy = wind_speed * math.sin(direction_rad) * scale
        
        return vx, vy
    def _initial_position(self, wind_field):
        """Position cloud at the upwind edge of the domain."""
        edge_buffer = CFG.SPAWN_BUFFER_M
        domain_size = CFG.DOMAIN_SIZE_M
        # Sample wind at center of domain
        wind_speed, wind_direction = wind_field.sample(domain_size/2, domain_size/2, self.altitude)
        
        # Convert direction to radians
        wind_dir_rad = math.radians(wind_direction)
        
        # Calculate wind vector components
        dx = math.cos(wind_dir_rad)
        dy = math.sin(wind_dir_rad)
        
        # Determine which edge to spawn based on wind direction
        wind_direction = math.degrees(math.atan2(dy, dx)) % 360
        
        # Position based on wind direction
        if 45 <= wind_direction < 135:  # Wind blowing from south
            x = random.uniform(-edge_buffer, domain_size + edge_buffer)
            y = -edge_buffer
        elif 135 <= wind_direction < 225:  # Wind blowing from west
            x = domain_size + edge_buffer
            y = random.uniform(-edge_buffer, domain_size + edge_buffer)
        elif 225 <= wind_direction < 315:  # Wind blowing from north
            x = random.uniform(-edge_buffer, domain_size + edge_buffer)
            y = domain_size + edge_buffer
        else:  # Wind blowing from east
            x = -edge_buffer
            y = random.uniform(-edge_buffer, domain_size + edge_buffer)
        
        return float(x), float(y)
    def _make_puffs(self):
        """Create a naturalistic cloud formation with overlapping puffs."""
        puffs = []
        # Smaller number of puffs for more natural clouds
        n = random.randint(3, 7)
        for _ in range(n):
            w = random.randint(1200, 2000)
            h = random.randint(1400, 1800)
            angle = random.random() * 2 * math.pi
            radius = random.uniform(0, 450)
            puffs.append(CloudPuff(radius*math.cos(angle), radius*math.sin(angle), w, h))
        return puffs
    def update_wind(self, wind_field):
        """Smoothly update cloud's wind velocity using global wind vector."""
        # Get new wind velocity
        new_vx, new_vy = self._wind_to_velocity(wind_field)
        
        # Store previous velocity
        prev_vx = self.vx
        prev_vy = self.vy
        
        # Smooth wind transitions (80% new, 20% old)
        self.vx = CFG.WIND_SMOOTH * new_vx + (1 - CFG.WIND_SMOOTH) * self.vx
        self.vy = CFG.WIND_SMOOTH * new_vy + (1 - CFG.WIND_SMOOTH) * self.vy
        
        # Update history
        self.velocity_history_x.appendleft(self.vx)
        self.velocity_history_y.appendleft(self.vy)
        self.acceleration_x = self.vx - prev_vx
        self.acceleration_y = self.vy - prev_vy
        self.ws = math.hypot(self.vx, self.vy)
        self.wd = (math.degrees(math.atan2(self.vy, self.vx)) + 360) % 360
    def step(self, frame_idx):
        """Move cloud based on wind and update puff opacities."""
        # Track position history
        self.position_history_x.appendleft(self.precise_x)
        self.position_history_y.appendleft(self.precise_y)
        
        # Update simulation time
        timestep = CFG.PHYSICS_TIMESTEP
        self.simulation_time += timestep * 60  # Convert to minutes
        
        # Altitude-based parallax (higher clouds appear to move slower)
        altitude_factor = max(0.5, 1.0 - CFG.ALT_PARALLAX_K * self.altitude)
        
        # Calculate distance to move with altitude factor
        movement_scale = CFG.MOVEMENT_MULTIPLIER * altitude_factor
        dx = self.vx * movement_scale
        dy = self.vy * movement_scale
        
        # Update position
        self.precise_x += dx
        self.precise_y += dy
        
        # Handle wrapping around the domain
        if CFG.CLOUD_WRAP_AROUND:
            domain_size = CFG.DOMAIN_SIZE_M
            buffer = CFG.SPAWN_BUFFER_M
            
            if self.precise_x < -buffer:
                self.precise_x = domain_size + buffer
            elif self.precise_x > domain_size + buffer:
                self.precise_x = -buffer
                
            if self.precise_y < -buffer:
                self.precise_y = domain_size + buffer
            elif self.precise_y > domain_size + buffer:
                self.precise_y = -buffer
        
        # Update integer position
        self.x, self.y = int(self.precise_x), int(self.precise_y)
        
        # Update rendering position
        self.render_x = self.precise_x
        self.render_y = self.precise_y
        
        # Update puffs - always fade toward min(age/60, 1.0)
        age_factor = min(self.age(frame_idx) / 60.0, 1.0)
        for puff in self.puffs:
            puff.fade_toward(age_factor)
    def age(self, frame_idx):
        """Calculate age in frames."""
        return frame_idx - self.birth
    def is_expired(self, frame_idx):
        """Check if cloud has exceeded its lifespan."""
        if CFG.SINGLE_CLOUD_MODE:
            return False
            
        domain_size = CFG.DOMAIN_SIZE_M
        outside_buffer = CFG.SPAWN_BUFFER_M * 2
        far_outside = (self.precise_x < -outside_buffer or 
                      self.precise_x > domain_size + outside_buffer or 
                      self.precise_y < -outside_buffer or 
                      self.precise_y > domain_size + outside_buffer)
        too_old = self.age(frame_idx) > CFG.PARCEL_MEAN_LIFE
        return too_old or (far_outside and not CFG.CLOUD_WRAP_AROUND)
# Weather System manages cloud parcels
class WeatherSystem:
    """
    Manages the overall weather simulation with natural cloud behavior.
    Handles cloud spawning, movement, and lifecycle.
    """
    def __init__(self):
        """Initialize the weather system with wind field and empty cloud list."""
        # Import here to avoid circular dependency
        from enhanced_wind_field import EnhancedWindField
        from enhanced_wind_field import WindFieldConfig
        
        # Configure wind field with layer heights and speeds
        config = WindFieldConfig(
            domain_size=CFG.DOMAIN_SIZE_M,
            grid_resolution=CFG.WIND_GRID,
            base_wind_speed=CFG.BASE_WIND_SPEED,
            num_layers=len(CFG.LAYER_HEIGHTS) - 1,
            layer_heights=CFG.LAYER_HEIGHTS,
            layer_speed_factors=CFG.LAYER_SPEED_FACTORS,
            layer_direction_offsets=CFG.LAYER_DIRECTION_OFFSETS
        )
        
        self.wind_field = EnhancedWindField(config)
        self.parcels = []
        self.frame_idx = 0
        self.last_wind_update = 0
        print(f"[DEBUG] Weather system initialized with realistic cloud movement")
        
        # Force initial cloud if needed
        if CFG.FORCE_INITIAL_CLOUD and not CFG.SINGLE_CLOUD_MODE:
            self.parcels.append(EnhancedCloudParcel(0, self.wind_field))
            print(f"[DEBUG] Initial cloud spawned")
    def spawn_maybe(self, frame_idx):
        """Spawn new clouds if needed based on current coverage."""
        # Don't spawn if we've reached the maximum or in single cloud mode
        if len(self.parcels) >= CFG.MAX_PARCELS or CFG.SINGLE_CLOUD_MODE:
            return
            
        # Spawn probability scales with unsatisfied cover
        need = CFG.MAX_PARCELS - len(self.parcels)
        if random.random() < need * CFG.SPAWN_PROBABILITY:
            self.parcels.append(EnhancedCloudParcel(frame_idx, self.wind_field))
            print(f"[DEBUG] Spawned new cloud at frame {frame_idx}, {len(self.parcels)}/{CFG.MAX_PARCELS} active")
    def step(self, frame_idx=None, dt=None):
        """Advance the weather simulation by one frame."""
        if frame_idx is not None:
            self.frame_idx = frame_idx
        else:
            self.frame_idx += 1
            
        # Update wind field based on time
        frames_per_update = CFG.WIND_UPDATE_SEC / CFG.PHYSICS_TIMESTEP
        if self.frame_idx - self.last_wind_update >= frames_per_update:
            self.last_wind_update = self.frame_idx
            if hasattr(self.wind_field, 'step'):
                self.wind_field.step(self.frame_idx)
        
        # Maybe create a new parcel
        self.spawn_maybe(self.frame_idx)
        
        # Update each parcel
        for p in list(self.parcels):
            p.update_wind(self.wind_field)
            p.step(self.frame_idx)
            if p.is_expired(self.frame_idx):
                self.parcels.remove(p)
                print(f"[DEBUG] Cloud expired at frame {self.frame_idx}, {len(self.parcels)} remaining")
    def current_cloud_cover_pct(self):
        """Calculate approximate cloud cover percentage."""
        # Each cloud contributes ~6% coverage
        cover = clamp(len(self.parcels) * 6, 0, 100)
        return cover
    def get_avg_trajectory(self):
        """Get average cloud trajectory vector."""
        if not self.parcels:
            return None, None, 0
            
        speeds = []
        directions_x = []
        directions_y = []
        
        for parcel in self.parcels:
            speeds.append(parcel.ws)
            direction_rad = math.radians(parcel.wd)
            directions_x.append(math.cos(direction_rad))
            directions_y.append(math.sin(direction_rad))
        
        # Calculate averages
        avg_speed = sum(speeds) / len(speeds)
        avg_dir_x = sum(directions_x) / len(directions_x)
        avg_dir_y = sum(directions_y) / len(directions_y)
        
        # Convert back to angle
        avg_direction = math.degrees(math.atan2(avg_dir_y, avg_dir_x)) % 360
        
        # Calculate confidence (higher for similar directions)
        mean_vector_length = math.sqrt(avg_dir_x**2 + avg_dir_y**2)
        confidence = mean_vector_length  # 1.0 = all same direction, 0.0 = perfectly opposing
        
        # Convert to km/h for display
        avg_speed_kmh = avg_speed * (3600 * 1000 / CFG.DOMAIN_SIZE_M) * CFG.AREA_SIZE_KM
        
        return avg_speed_kmh, avg_direction, confidence
# Helper function to collect visible ellipses for rendering
def collect_visible_ellipses(parcels):
    """
    Collect ellipse parameters from all visible cloud puffs.
    Returns a LIST of tuples (x, y, width, height, rotation_rad, opacity, altitude).
    """
    result = []
    for parcel in parcels:
        for puff in parcel.puffs:
            if puff.opacity < 0.03:  # Skip nearly invisible puffs
                continue
            # Make sure the opacity is at least 0.1 for better visibility
            visible_opacity = max(0.1, puff.opacity)
            result.append((
                parcel.precise_x + puff.rel_x,
                parcel.precise_y + puff.rel_y,
                puff.width,
                puff.height,
                puff.rotation,
                visible_opacity,
                parcel.altitude
            ))
    return result
def create_cloud_surface(ellipse_params, width, height):
    """Create a pygame surface for a cloud puff."""
    cx, cy, cw, ch, crot, cop, alt = ellipse_params
    
    # Create a surface sized to fit the ellipse
    padding = 4  # Extra space for rotation
    surf_w = int(cw * padding)
    surf_h = int(ch * padding)
    surf = pygame.Surface((surf_w, surf_h), pygame.SRCALPHA)
    
    # Draw the ellipse
    alpha = int(cop * 255)
    pygame.draw.ellipse(surf, (255, 255, 255, alpha), (
        surf_w//2 - cw//2,
        surf_h//2 - ch//2,
        cw, ch
    ))
    
    # Add a highlight
    highlight_w = int(cw * 0.7)
    highlight_h = int(ch * 0.7)
    highlight_rect = pygame.Rect(
        surf_w//2 - highlight_w//2,
        surf_h//2 - highlight_h//2,
        highlight_w, highlight_h
    )
    pygame.draw.ellipse(surf, (255, 255, 255, alpha//2), highlight_rect)
    
    # Rotate if needed
    if crot != 0:
        surf = pygame.transform.rotate(surf, math.degrees(crot))
    
    # Get the position for rendering
    pos = (int(cx) - surf.get_width()//2, int(cy) - surf.get_height()//2)
    
    return surf, pos
def draw_cloud_trail(screen, positions, x_range, y_range, width, height):
    """Draw a trail showing cloud movement."""
    if len(positions) < 2:
        return
    
    # Convert positions to screen coordinates
    screen_points = []
    range_x = x_range[1] - x_range[0]
    range_y = y_range[1] - y_range[0]
    
    for x, y in positions:
        screen_x = int((x - x_range[0]) / range_x * width)
        screen_y = int((y - y_range[0]) / range_y * height)
        screen_points.append((screen_x, screen_y))
    
    # Draw lines connecting points
    for i in range(len(screen_points) - 1):
        start = screen_points[i]
        end = screen_points[i + 1]
        
        # Fade out older points
        alpha = int(255 * (1.0 - i / len(screen_points)))
        
        pygame.draw.line(screen, (255, 0, 0, alpha), start, end, 2)