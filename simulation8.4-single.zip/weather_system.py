import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
import json

@dataclass
class WeatherState:
    """Current weather conditions."""
    timestamp: datetime
    temperature: float  # Celsius
    pressure: float  # hPa
    humidity: float  # %
    wind_speed: float  # m/s
    wind_direction: float  # degrees
    cloud_cover: float  # fraction (0-1)
    cloud_type: str
    visibility: float  # km
    precipitation: float  # mm/hr
    solar_radiation: Dict  # DNI, DHI, GHI measurements

class WeatherSystem:
    """
    Comprehensive weather system that provides realistic atmospheric conditions
    for solar farm simulation.
    """
    
    def __init__(self, location: Dict):
        """
        Initialize weather system for specific location.
        
        Args:
            location: Dict with 'latitude', 'longitude', 'altitude', 'timezone'
        """
        self.location = location
        self.current_state = None
        self.forecast = []
        
        # Weather patterns
        self.diurnal_patterns = self._initialize_diurnal_patterns()
        self.seasonal_patterns = self._initialize_seasonal_patterns()
        
        # Atmospheric parameters
        self.turbidity_model = TurbidityModel(location)
        self.cloud_model = CloudModel()
        
    def _initialize_diurnal_patterns(self) -> Dict:
        """Initialize typical daily weather patterns."""
        return {
            'temperature': {
                'min_hour': 6,
                'max_hour': 15,
                'amplitude': 8  # Daily temperature range
            },
            'humidity': {
                'min_hour': 15,
                'max_hour': 6,
                'amplitude': 20
            },
            'wind_speed': {
                'min_hour': 6,
                'max_hour': 15,
                'amplitude': 3
            },
            'cloud_formation': {
                'morning_fog': {'start': 5, 'end': 8, 'probability': 0.3},
                'afternoon_cumulus': {'start': 11, 'end': 17, 'probability': 0.4},
                'evening_clear': {'start': 18, 'end': 22, 'probability': 0.7}
            }
        }
    
    def _initialize_seasonal_patterns(self) -> Dict:
        """Initialize seasonal weather variations."""
        return {
            'summer': {
                'temp_range': (25, 35),
                'humidity_range': (50, 80),
                'cloud_types': ['cumulus', 'cumulonimbus'],
                'turbidity': 4.0
            },
            'monsoon': {
                'temp_range': (22, 30),
                'humidity_range': (70, 95),
                'cloud_types': ['nimbostratus', 'cumulonimbus'],
                'turbidity': 5.0
            },
            'winter': {
                'temp_range': (18, 28),
                'humidity_range': (40, 70),
                'cloud_types': ['cirrus', 'altocumulus'],
                'turbidity': 2.5
            }
        }
    
    def update(self, timestamp: datetime) -> WeatherState:
        """Update weather state for given timestamp."""
        # Determine season
        season = self._get_season(timestamp)
        seasonal_params = self.seasonal_patterns[season]
        
        # Calculate base values
        hour = timestamp.hour + timestamp.minute / 60
        
        # Temperature
        temp_min, temp_max = seasonal_params['temp_range']
        temp = self._calculate_diurnal_value(
            hour, temp_min, temp_max,
            self.diurnal_patterns['temperature']
        )
        
        # Humidity (inverse of temperature)
        humidity_min, humidity_max = seasonal_params['humidity_range']
        humidity = self._calculate_diurnal_value(
            hour, humidity_max, humidity_min,  # Note: reversed
            self.diurnal_patterns['humidity']
        )
        
        # Wind
        wind_base = 2.0
        wind_amplitude = self.diurnal_patterns['wind_speed']['amplitude']
        wind_speed = self._calculate_diurnal_value(
            hour, wind_base, wind_base + wind_amplitude,
            self.diurnal_patterns['wind_speed']
        )
        
        # Wind direction (prevailing + random variation)
        wind_direction = 225 + np.random.normal(0, 20)  # SW prevailing
        
        # Pressure (small variations)
        pressure = 1013 + np.random.normal(0, 5)
        
        # Cloud cover and type
        cloud_data = self._determine_clouds(hour, season)
        
        # Visibility
        visibility = self._calculate_visibility(humidity, cloud_data['cloud_cover'])
        
        # Precipitation
        precipitation = self._calculate_precipitation(cloud_data['cloud_type'], humidity)
        
        # Solar radiation (if daytime)
        solar_radiation = self._calculate_solar_radiation(
            timestamp, cloud_data['cloud_cover'], seasonal_params['turbidity']
        )
        
        # Create weather state
        self.current_state = WeatherState(
            timestamp=timestamp,
            temperature=temp,
            pressure=pressure,
            humidity=humidity,
            wind_speed=wind_speed,
            wind_direction=wind_direction % 360,
            cloud_cover=cloud_data['cloud_cover'],
            cloud_type=cloud_data['cloud_type'],
            visibility=visibility,
            precipitation=precipitation,
            solar_radiation=solar_radiation
        )
        
        return self.current_state
    
    def _calculate_diurnal_value(self, hour: float, min_val: float, max_val: float,
                               pattern: Dict) -> float:
        """Calculate value following diurnal pattern."""
        min_hour = pattern['min_hour']
        max_hour = pattern['max_hour']
        
        # Simple sinusoidal model
        if min_hour < max_hour:
            # Normal case (min in morning, max in afternoon)
            phase = (hour - min_hour) / (max_hour - min_hour) * np.pi
        else:
            # Inverted case (min in afternoon, max in morning)
            if hour >= max_hour:
                phase = (hour - max_hour) / (24 - max_hour + min_hour) * np.pi
            else:
                phase = (hour + 24 - max_hour) / (24 - max_hour + min_hour) * np.pi
                
        value = min_val + (max_val - min_val) * (0.5 + 0.5 * np.sin(phase - np.pi/2))
        
        # Add random variation
        value += np.random.normal(0, (max_val - min_val) * 0.05)
        
        return value
    
    def _get_season(self, timestamp: datetime) -> str:
        """Determine season based on date (for tropical location)."""
        month = timestamp.month
        
        if month in [6, 7, 8, 9]:
            return 'monsoon'
        elif month in [3, 4, 5]:
            return 'summer'
        else:
            return 'winter'
    
    def _determine_clouds(self, hour: float, season: str) -> Dict:
        """Determine cloud cover and type based on time and season."""
        cloud_patterns = self.diurnal_patterns['cloud_formation']
        seasonal_clouds = self.seasonal_patterns[season]['cloud_types']
        
        # Check each cloud formation period
        cloud_cover = 0.0
        cloud_type = 'clear'
        
        for period_name, period in cloud_patterns.items():
            if period['start'] <= hour <= period['end']:
                if np.random.random() < period['probability']:
                    if 'fog' in period_name:
                        cloud_cover = np.random.uniform(0.6, 0.9)
                        cloud_type = 'stratus'
                    elif 'cumulus' in period_name:
                        cloud_cover = np.random.uniform(0.3, 0.7)
                        cloud_type = np.random.choice(seasonal_clouds)
                    else:
                        cloud_cover = np.random.uniform(0, 0.3)
                        cloud_type = 'clear'
                        
        return {'cloud_cover': cloud_cover, 'cloud_type': cloud_type}
    
    def _calculate_visibility(self, humidity: float, cloud_cover: float) -> float:
        """Calculate visibility based on humidity and clouds."""
        # Base visibility
        base_vis = 50  # km
        
        # Humidity effect (exponential decay)
        humidity_factor = np.exp(-0.02 * (humidity - 40))
        
        # Cloud effect
        cloud_factor = 1 - 0.5 * cloud_cover
        
        visibility = base_vis * humidity_factor * cloud_factor
        
        return max(1, visibility)
    
    def _calculate_precipitation(self, cloud_type: str, humidity: float) -> float:
        """Calculate precipitation rate."""
        precip_rates = {
            'clear': 0,
            'cirrus': 0,
            'altocumulus': 0,
            'cumulus': 0.1 if humidity > 80 else 0,
            'stratocumulus': 0.5 if humidity > 85 else 0,
            'nimbostratus': 2.0,
            'cumulonimbus': 10.0 if humidity > 75 else 0
        }
        
        base_rate = precip_rates.get(cloud_type, 0)
        
        # Random variation
        if base_rate > 0:
            base_rate *= np.random.uniform(0.5, 1.5)
            
        return base_rate
    
    def _calculate_solar_radiation(self, timestamp: datetime, cloud_cover: float,
                                 turbidity: float) -> Dict:
        """Calculate solar radiation components."""
        from clear_sky_generation import EnhancedClearSkyGeneration
        
        # Create clear sky model
        clear_sky = EnhancedClearSkyGeneration(
            latitude=self.location['latitude'],
            longitude=self.location['longitude'],
            altitude=self.location['altitude']
        )
        
        # Get clear sky values
        clear_sky_rad = clear_sky.calculate_irradiance_components(timestamp)
        
        # Apply cloud effects
        # Simple model - more sophisticated version in cloud physics module
        cloud_factor = 1 - cloud_cover * 0.75
        
        return {
            'dni': clear_sky_rad['dni'] * cloud_factor,
            'dhi': clear_sky_rad['dhi'] * (1 + cloud_cover * 0.2),  # Diffuse increases
            'ghi': clear_sky_rad['ghi'] * (1 - cloud_cover * 0.5),
            'clear_sky_dni': clear_sky_rad['dni'],
            'clear_sky_ghi': clear_sky_rad['ghi']
        }
    
    def get_forecast(self, hours_ahead: int = 24) -> List[WeatherState]:
        """Generate weather forecast."""
        forecast = []
        current = datetime.now()
        
        for hour in range(hours_ahead):
            future_time = current + timedelta(hours=hour)
            weather = self.update(future_time)
            forecast.append(weather)
            
        return forecast
    
    def get_historical_data(self, start_date: datetime, end_date: datetime) -> pd.DataFrame:
        """Generate historical weather data."""
        data = []
        current = start_date
        
        while current <= end_date:
            weather = self.update(current)
            data.append({
                'timestamp': weather.timestamp,
                'temperature': weather.temperature,
                'humidity': weather.humidity,
                'wind_speed': weather.wind_speed,
                'wind_direction': weather.wind_direction,
                'cloud_cover': weather.cloud_cover,
                'dni': weather.solar_radiation['dni'],
                'dhi': weather.solar_radiation['dhi'],
                'ghi': weather.solar_radiation['ghi']
            })
            current += timedelta(minutes=5)
            
        return pd.DataFrame(data)

class TurbidityModel:
    """Model atmospheric turbidity variations."""
    
    def __init__(self, location: Dict):
        self.location = location
        self.base_turbidity = self._get_base_turbidity()
        
    def _get_base_turbidity(self) -> float:
        """Get base turbidity for location."""
        # Simplified - could use actual data
        if self.location['altitude'] > 1000:
            return 2.0  # Mountain
        elif abs(self.location['latitude']) > 40:
            return 2.5  # Temperate
        else:
            return 3.5  # Tropical
            
    def get_turbidity(self, timestamp: datetime, weather_state: WeatherState) -> float:
        """Calculate current turbidity."""
        base = self.base_turbidity
        
        # Seasonal variation
        month = timestamp.month
        seasonal_factor = 1 + 0.3 * np.sin((month - 6) * np.pi / 6)
        
        # Humidity effect
        humidity_factor = 1 + 0.01 * (weather_state.humidity - 50)
        
        # After rain effect
        if weather_state.precipitation > 0:
            rain_factor = 0.7  # Cleaner air
        else:
            rain_factor = 1.0
            
        turbidity = base * seasonal_factor * humidity_factor * rain_factor
        
        return max(1.5, min(6.0, turbidity))

class CloudModel:
    """Advanced cloud modeling for weather system."""
    
    def __init__(self):
        self.cloud_database = self._load_cloud_properties()
        
    def _load_cloud_properties(self) -> Dict:
        """Load detailed cloud properties."""
        return {
            'cumulus': {
                'base_height': 500,  # meters
                'thickness': 1000,
                'albedo': 0.65,
                'emissivity': 0.95,
                'liquid_water_path': 50  # g/m²
            },
            'stratus': {
                'base_height': 200,
                'thickness': 500,
                'albedo': 0.60,
                'emissivity': 0.98,
                'liquid_water_path': 100
            },
            'cirrus': {
                'base_height': 8000,
                'thickness': 2000,
                'albedo': 0.30,
                'emissivity': 0.50,
                'liquid_water_path': 5
            },
            'cumulonimbus': {
                'base_height': 500,
                'thickness': 10000,
                'albedo': 0.90,
                'emissivity': 1.0,
                'liquid_water_path': 500
            }
        }
    
    def get_cloud_properties(self, cloud_type: str) -> Dict:
        """Get detailed properties for cloud type."""
        return self.cloud_database.get(cloud_type, self.cloud_database['cumulus'])