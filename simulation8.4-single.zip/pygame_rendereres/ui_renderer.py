import pygame
import numpy as np
import math

def draw_text(screen, text, position, font_size=16, color=(0, 0, 0), 
             bg_color=None, bold=False, center=False, padding=0):
    """Draw text on the screen with optional background."""
    font = pygame.font.SysFont('Arial', font_size, bold=bold)
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect()
    
    if center:
        text_rect.center = position
    else:
        text_rect.topleft = position
        
    if bg_color is not None:
        # Check if bg_color has alpha
        if len(bg_color) == 4:
            # Create a surface with per-pixel alpha
            bg_surface = pygame.Surface((text_rect.width + padding*2, text_rect.height + padding*2), pygame.SRCALPHA)
            bg_surface.fill(bg_color)
            bg_rect = bg_surface.get_rect()
            bg_rect.center = text_rect.center
            screen.blit(bg_surface, (bg_rect.x, bg_rect.y))
        else:
            # Regular background
            bg_rect = text_rect.inflate(padding*2, padding*2)
            pygame.draw.rect(screen, bg_color, bg_rect, border_radius=padding)
            
    screen.blit(text_surface, text_rect)
    return text_rect

def create_info_panel(screen, info_dict, title=None, position=(20, 20), width=200):
    """Create an information panel with multiple lines of text."""
    # Panel settings
    padding = 10
    line_height = 24
    bg_color = (255, 255, 255, 180)  # Semi-transparent white
    border_color = (0, 0, 0)
    
    # Calculate panel dimensions
    num_lines = len(info_dict) + (1 if title else 0)
    panel_height = padding * 2 + line_height * num_lines
    
    # Create panel background
    panel_rect = pygame.Rect(position[0], position[1], width, panel_height)
    
    # Draw panel background with alpha
    bg_surface = pygame.Surface((width, panel_height), pygame.SRCALPHA)
    bg_surface.fill(bg_color)
    screen.blit(bg_surface, position)
    
    # Draw border
    pygame.draw.rect(screen, border_color, panel_rect, width=1, border_radius=3)
    
    # Draw title if provided
    y_offset = position[1] + padding
    if title:
        draw_text(
            screen, title, 
            (position[0] + padding, y_offset),
            font_size=16, bold=True
        )
        y_offset += line_height
    
    # Draw info lines
    for key, value in info_dict.items():
        text = f"{key}: {value}"
        draw_text(
            screen, text, 
            (position[0] + padding, y_offset),
            font_size=14
        )
        y_offset += line_height
    
    return panel_rect

def draw_trajectory_info(screen, cloud_speed, cloud_direction, confidence, position=(20, 220)):
    """Draw cloud trajectory information with direction arrow."""
    if cloud_speed is None or cloud_direction is None:
        text = "Cloud Movement: Not enough data"
        draw_text(screen, text, position, font_size=14, bold=True)
        return
    
    # Create trajectory panel
    panel_width = 200
    panel_height = 160
    panel_rect = pygame.Rect(position[0], position[1], panel_width, panel_height)
    
    # Panel background
    bg_color = (255, 255, 255, 180)
    bg_surface = pygame.Surface((panel_width, panel_height), pygame.SRCALPHA)
    bg_surface.fill(bg_color)
    screen.blit(bg_surface, position)
    
    # Panel border
    pygame.draw.rect(screen, (0, 0, 0), panel_rect, width=1, border_radius=3)
    
    # Title
    title_pos = (position[0] + 10, position[1] + 10)
    title_rect = draw_text(screen, "Cloud Movement", title_pos, font_size=16, bold=True)
    
    # Speed and direction text
    text_pos = (position[0] + 10, title_rect.bottom + 10)
    speed_text = f"Speed: {cloud_speed:.1f} km/h"
    speed_rect = draw_text(screen, speed_text, text_pos, font_size=14)
    
    dir_pos = (position[0] + 10, speed_rect.bottom + 5)
    dir_text = f"Direction: {cloud_direction:.0f}°"
    dir_rect = draw_text(screen, dir_text, dir_pos, font_size=14)
    
    conf_pos = (position[0] + 10, dir_rect.bottom + 5)
    conf_text = f"Confidence: {int(confidence * 100)}%"
    draw_text(screen, conf_text, conf_pos, font_size=14)
    
    # Direction arrow
    arrow_center = (
        position[0] + panel_width // 2,
        position[1] + panel_height - 40
    )
    arrow_length = 30
    
    # Convert direction from degrees to radians (0° is East, 90° is North)
    direction_rad = math.radians(cloud_direction)
    
    # Calculate arrow endpoint
    end_x = arrow_center[0] + arrow_length * math.cos(direction_rad)
    end_y = arrow_center[1] - arrow_length * math.sin(direction_rad)
    
    # Draw compass circle
    pygame.draw.circle(screen, (230, 230, 230), arrow_center, arrow_length + 5, width=0)
    pygame.draw.circle(screen, (0, 0, 0), arrow_center, arrow_length + 5, width=1)
    
    # Draw N/E/S/W indicators
    compass_points = [
        ("N", 0, -1),
        ("E", 1, 0),
        ("S", 0, 1),
        ("W", -1, 0)
    ]
    
    small_font = pygame.font.SysFont('Arial', 10, bold=True)
    for label, dx, dy in compass_points:
        point_x = arrow_center[0] + (arrow_length + 15) * dx
        point_y = arrow_center[1] + (arrow_length + 15) * dy
        text = small_font.render(label, True, (0, 0, 0))
        text_rect = text.get_rect(center=(point_x, point_y))
        screen.blit(text, text_rect)
    
    # Arrow color based on confidence
    if confidence > 0.7:
        arrow_color = (0, 120, 0)  # Green for high confidence
    elif confidence > 0.3:
        arrow_color = (150, 150, 0)  # Yellow for medium confidence
    else:
        arrow_color = (150, 0, 0)  # Red for low confidence
    
    # Draw arrow
    pygame.draw.line(screen, arrow_color, arrow_center, (end_x, end_y), width=3)
    
    # Draw arrowhead
    head_length = 10
    head_width = 6
    
    # Calculate perpendicular direction for arrowhead
    perp_x = math.sin(direction_rad)
    perp_y = math.cos(direction_rad)
    
    # Calculate arrowhead points
    head_point1 = (
        end_x - head_length * math.cos(direction_rad) + head_width * perp_x,
        end_y + head_length * math.sin(direction_rad) + head_width * perp_y
    )
    head_point2 = (
        end_x - head_length * math.cos(direction_rad) - head_width * perp_x,
        end_y + head_length * math.sin(direction_rad) - head_width * perp_y
    )
    
    # Draw arrowhead
    pygame.draw.polygon(screen, arrow_color, [(end_x, end_y), head_point1, head_point2])
    
    return panel_rect

def draw_affected_panels_list(screen, affected_panels, total_panels, power_output, position=(800, 20)):
    """Draw a list of affected panels with power information."""
    if not affected_panels:
        return
    
    # Panel settings
    panel_width = 300
    panel_height = 250
    padding = 10
    line_height = 20
    
    # Create panel
    panel_rect = pygame.Rect(position[0], position[1], panel_width, panel_height)
    
    # Panel background
    bg_color = (255, 255, 255, 180)
    bg_surface = pygame.Surface((panel_width, panel_height), pygame.SRCALPHA)
    bg_surface.fill(bg_color)
    screen.blit(bg_surface, position)
    
    # Panel border
    pygame.draw.rect(screen, (0, 0, 0), panel_rect, width=1, border_radius=3)
    
    # Title
    title_pos = (position[0] + padding, position[1] + padding)
    affected_count = len(affected_panels)
    affected_pct = affected_count / total_panels * 100 if total_panels > 0 else 0
    
    title = f"Affected Panels: {affected_count}/{total_panels} ({affected_pct:.1f}%)"
    title_rect = draw_text(screen, title, title_pos, font_size=16, bold=True)
    
    # List header
    header_pos = (position[0] + padding, title_rect.bottom + 10)
    header = "Panel ID      Reduction      Power"
    header_rect = draw_text(screen, header, header_pos, font_size=14)
    
    # Draw separator line
    line_y = header_rect.bottom + 5
    pygame.draw.line(
        screen, (0, 0, 0), 
        (position[0] + 5, line_y), 
        (position[0] + panel_width - 5, line_y),
        width=1
    )
    
    # List affected panels (up to 10)
    y_pos = line_y + 10
    for i, panel_id in enumerate(affected_panels[:10]):
        if panel_id not in power_output:
            continue
            
        power_data = power_output[panel_id]
        baseline = power_data.get('baseline', 0)
        current = power_data.get('final_power', 0)
        
        if baseline > 0:
            reduction = (baseline - current) / baseline * 100
        else:
            reduction = 0
            
        # Text with formatting
        text = f"{panel_id:<10}   {reduction:>6.1f}%     {current:.2f} kW"
        
        # Color based on reduction
        if reduction > 50:
            color = (180, 0, 0)  # Red for high reduction
        elif reduction > 20:
            color = (180, 120, 0)  # Orange for medium
        else:
            color = (0, 120, 0)  # Green for low
            
        draw_text(screen, text, (position[0] + padding, y_pos), font_size=12, color=color)
        y_pos += line_height
        
    # If there are more affected panels than shown
    if len(affected_panels) > 10:
        more_text = f"...and {len(affected_panels) - 10} more panels"
        draw_text(screen, more_text, (position[0] + padding, y_pos + 5), font_size=12, color=(100, 100, 100))
    
    return panel_rect

def draw_time_slider(screen, current_hour, sunrise_hour, sunset_hour, position, width):
    """Draw a time slider showing current simulation time in daylight context."""
    # Settings
    height = 20
    padding = 5
    
    # Convert hours to positions
    day_start = 0
    day_end = 24
    day_length = day_end - day_start
    
    # Calculate pixel positions
    x_pos = position[0]
    y_pos = position[1]
    
    # Draw background bar
    bg_rect = pygame.Rect(x_pos, y_pos, width, height)
    pygame.draw.rect(screen, (220, 220, 220), bg_rect, border_radius=height//2)
    pygame.draw.rect(screen, (0, 0, 0), bg_rect, width=1, border_radius=height//2)
    
    # Draw daylight portion
    if sunrise_hour < sunset_hour:
        daylight_start = (sunrise_hour - day_start) / day_length * width
        daylight_width = (sunset_hour - sunrise_hour) / day_length * width
        
        daylight_rect = pygame.Rect(
            x_pos + daylight_start, 
            y_pos, 
            daylight_width, 
            height
        )
        
        # Gradient from dark blue to yellow to dark blue
        gradient_surface = pygame.Surface((int(daylight_width), height), pygame.SRCALPHA)
        
        # Create gradient
        for x in range(int(daylight_width)):
            # Position in daylight (0 to 1)
            pos = x / daylight_width
            
            # Color varies from dark blue to yellow to dark blue
            if pos < 0.5:
                # Morning: Blue to yellow
                r = int(255 * (pos * 2))
                g = int(200 * (pos * 2))
                b = int(255 * (1 - pos))
            else:
                # Afternoon: Yellow to blue
                adjusted_pos = (pos - 0.5) * 2  # 0 to 1
                r = int(255 * (1 - adjusted_pos))
                g = int(200 * (1 - adjusted_pos))
                b = int(255 * adjusted_pos)
                
            # Draw vertical line of this color
            pygame.draw.line(gradient_surface, (r, g, b), (x, 0), (x, height))
            
        # Apply the gradient
        screen.blit(gradient_surface, (x_pos + daylight_start, y_pos))
        
        # Redraw border (it got covered by our gradient)
        pygame.draw.rect(screen, (0, 0, 0), bg_rect, width=1, border_radius=height//2)
    
    # Draw hour markers
    for hour in range(day_start, day_end + 1, 3):
        marker_x = x_pos + (hour - day_start) / day_length * width
        
        # Taller markers for main hours
        marker_height = height + 5
        
        # Draw marker line
        pygame.draw.line(
            screen, (0, 0, 0),
            (marker_x, y_pos + height),
            (marker_x, y_pos + height + 5),
            width=1
        )
        
        # Draw hour text
        hour_text = f"{hour:02d}:00"
        draw_text(
            screen, hour_text,
            (marker_x, y_pos + height + 8),
            font_size=10, center=True
        )
    
    # Draw current time indicator
    if day_start <= current_hour <= day_end:
        current_x = x_pos + (current_hour - day_start) / day_length * width
        
        # Triangle pointer
        pointer_height = 15
        pointer_width = 10
        
        pointer_points = [
            (current_x, y_pos - 5),
            (current_x - pointer_width//2, y_pos - 5 - pointer_height),
            (current_x + pointer_width//2, y_pos - 5 - pointer_height)
        ]
        
        pygame.draw.polygon(screen, (200, 0, 0), pointer_points)
        
        # Current time text
        hour = int(current_hour)
        minute = int((current_hour - hour) * 60)
        time_text = f"{hour:02d}:{minute:02d}"
        
        draw_text(
            screen, time_text,
            (current_x, y_pos - 25),
            font_size=14, bold=True, center=True,
            bg_color=(255, 255, 255, 200), padding=5
        )