import pygame
import math
import numpy as np
import matplotlib.patches as patches
from matplotlib.path import Path

def km_to_screen_coords(x_km, y_km, x_range, y_range, screen_width, screen_height):
    range_x = x_range[1] - x_range[0]
    range_y = y_range[1] - y_range[0]
    screen_x = int((x_km - x_range[0]) / range_x * screen_width)
    screen_y = int((y_km - y_range[0]) / range_y * screen_height)
    return screen_x, screen_y

def create_cloud_surface(ellipse_params, domain_size, area_size_km, width, height, x_range, y_range):
    cx, cy, cw, ch, crot, cop = ellipse_params
    
    # Convert domain coordinates to km
    km_x = cx / domain_size * area_size_km
    km_y = cy / domain_size * area_size_km
    width_km = cw / domain_size * area_size_km
    height_km = ch / domain_size * area_size_km
    
    # Convert km to screen coordinates
    screen_x, screen_y = km_to_screen_coords(km_x, km_y, x_range, y_range, width, height)
    screen_w = int(width_km / (x_range[1] - x_range[0]) * width)
    screen_h = int(height_km / (y_range[1] - y_range[0]) * height)
    
    # Ensure minimum size
    screen_w = max(10, screen_w)
    screen_h = max(10, screen_h)
    
    # Create cloud surface with alpha channel
    cloud_surface = pygame.Surface((screen_w * 2, screen_h * 2), pygame.SRCALPHA)
    
    # Calculate alpha based on opacity
    alpha = int(min(0.95, cop) * 255)
    
    # Draw cloud
    cloud_color = (255, 255, 255, alpha)
    ellipse_rect = pygame.Rect(0, 0, screen_w, screen_h)
    ellipse_rect.center = (cloud_surface.get_width() // 2, cloud_surface.get_height() // 2)
    
    # Draw main cloud body
    pygame.draw.ellipse(cloud_surface, cloud_color, ellipse_rect)
    
    # Add soft edge
    edge_color = (255, 255, 255, alpha // 3)
    edge_rect = ellipse_rect.inflate(screen_w * 0.2, screen_h * 0.2)
    pygame.draw.ellipse(cloud_surface, edge_color, edge_rect)
    
    # Rotate the surface if needed
    if crot != 0:
        cloud_surface = pygame.transform.rotate(cloud_surface, -math.degrees(crot))
    
    # Calculate position
    pos = (
        screen_x - cloud_surface.get_width() // 2,
        screen_y - cloud_surface.get_height() // 2
    )
    
    return cloud_surface, pos

def interpolate_clouds(source_ellipses, target_ellipses, t, domain_size, area_size_km):
    """
    Interpolate between two sets of cloud ellipses.
    Returns a list of matplotlib patches representing the clouds.
    """
    if len(source_ellipses) == 0 and len(target_ellipses) == 0:
        return []
    
    cloud_patches = []
    
    # Handle empty source or target
    if len(source_ellipses) == 0:
        for e in target_ellipses:
            cx, cy, cw, ch, crot, cop = e
            km_x = cx / domain_size * area_size_km
            km_y = cy / domain_size * area_size_km
            width_km = cw / domain_size * area_size_km
            height_km = ch / domain_size * area_size_km
            
            # Scale opacity with t
            opacity = cop * t
            
            # Create ellipse patch
            ellipse = patches.Ellipse(
                (km_x, km_y), width_km, height_km,
                angle=math.degrees(crot),
                facecolor=(1, 1, 1, opacity),
                edgecolor=(0.9, 0.9, 0.9, opacity),
                linewidth=0.5
            )
            cloud_patches.append(ellipse)
        return cloud_patches
    
    if len(target_ellipses) == 0:
        for e in source_ellipses:
            cx, cy, cw, ch, crot, cop = e
            km_x = cx / domain_size * area_size_km
            km_y = cy / domain_size * area_size_km
            width_km = cw / domain_size * area_size_km
            height_km = ch / domain_size * area_size_km
            
            # Scale opacity with 1-t (fade out)
            opacity = cop * (1-t)
            
            # Create ellipse patch
            ellipse = patches.Ellipse(
                (km_x, km_y), width_km, height_km,
                angle=math.degrees(crot),
                facecolor=(1, 1, 1, opacity),
                edgecolor=(0.9, 0.9, 0.9, opacity),
                linewidth=0.5
            )
            cloud_patches.append(ellipse)
        return cloud_patches
    
    # Interpolate between existing clouds
    for i, e1 in enumerate(source_ellipses):
        if i < len(target_ellipses):
            e2 = target_ellipses[i]
            
            # Interpolate parameters
            cx1, cy1, cw1, ch1, crot1, cop1 = e1
            cx2, cy2, cw2, ch2, crot2, cop2 = e2
            
            # Convert domain to km
            km_x1 = cx1 / domain_size * area_size_km
            km_y1 = cy1 / domain_size * area_size_km
            km_x2 = cx2 / domain_size * area_size_km
            km_y2 = cy2 / domain_size * area_size_km
            
            width_km1 = cw1 / domain_size * area_size_km
            height_km1 = ch1 / domain_size * area_size_km
            width_km2 = cw2 / domain_size * area_size_km
            height_km2 = ch2 / domain_size * area_size_km
            
            # Linear interpolation
            km_x = km_x1 + t * (km_x2 - km_x1)
            km_y = km_y1 + t * (km_y2 - km_y1)
            width_km = width_km1 + t * (width_km2 - width_km1)
            height_km = height_km1 + t * (height_km2 - height_km1)
            
            # Rotation needs special handling for shortest path
            rot1_deg = math.degrees(crot1)
            rot2_deg = math.degrees(crot2)
            delta_rot = ((rot2_deg - rot1_deg + 180) % 360) - 180
            rot_deg = rot1_deg + t * delta_rot
            
            # Opacity
            opacity = cop1 + t * (cop2 - cop1)
            
            # Create ellipse patch
            ellipse = patches.Ellipse(
                (km_x, km_y), width_km, height_km,
                angle=rot_deg,
                facecolor=(1, 1, 1, opacity),
                edgecolor=(0.9, 0.9, 0.9, opacity),
                linewidth=0.5
            )
            cloud_patches.append(ellipse)
    
    return cloud_patches

def draw_cloud_trail(screen, cloud_positions, x_range, y_range, width, height):
    """
    Draw a trail showing cloud movement history.
    """
    if len(cloud_positions) < 2:
        return
    
    # Convert km positions to screen coordinates
    screen_positions = []
    for km_x, km_y in cloud_positions:
        screen_x, screen_y = km_to_screen_coords(km_x, km_y, x_range, y_range, width, height)
        screen_positions.append((screen_x, screen_y))
    
    # Draw lines connecting positions
    for i in range(1, len(screen_positions)):
        start_pos = screen_positions[i-1]
        end_pos = screen_positions[i]
        
        # Increasing alpha for more recent positions
        alpha = int(i / len(screen_positions) * 180)
        color = (100, 100, 250, alpha)
        
        pygame.draw.line(screen, color, start_pos, end_pos, width=2)
    
    # Draw small circles at each position
    for i, pos in enumerate(screen_positions):
        alpha = int((i + 1) / len(screen_positions) * 200)
        color = (100, 100, 250, alpha)
        
        radius = 3 + i
        pygame.draw.circle(screen, color, pos, radius=radius)